﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    //declaring variable
    private Vector3 startPos;

     void Start()
    {
        //setting variable
        startPos = transform.position;
    }

    void Update()
    {
        //calling fucntion to check if it should die
        checkDead();
    }


    void OnCollisionEnter2D(Collision2D collision)
    {
        //if it collides with something delete the object
        Destroy(gameObject);
    }


    void checkDead()
    {
        // if the bullet is further than the start position delete it
        if (transform.position.x > startPos.x +10 ||
            transform.position.x < startPos.x - 10 ||
            transform.position.y > startPos.y + 10 ||
            transform.position.y < startPos.y - 10)
        {
            Destroy(gameObject);
        }

    }
}
