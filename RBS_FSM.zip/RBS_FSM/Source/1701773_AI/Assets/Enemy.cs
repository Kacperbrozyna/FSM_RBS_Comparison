﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    //declaring variables 
    public GameObject target;
    private gameplayManager GamePlayManager;

    void Start()
    {
        //setting the variable at the start of the game
        GamePlayManager = GameObject.FindObjectOfType<gameplayManager>();
    }

    // Update is called once per frame
    void Update()
    {
        //move the enemy towards the turret
        transform.position = Vector2.MoveTowards(transform.position, target.transform.position, GamePlayManager.enemyMoveSpeed * Time.deltaTime);

        //gets the direction between the enemy and the turret then rotate the enemy towards the turret
        var offset = -90f;
        Vector2 direction = (Vector2)target.transform.position - (Vector2)transform.position;
        direction.Normalize();
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.Euler(Vector3.forward * (angle + offset));

    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        //if there is a collsion between the enemy
        if (collision.gameObject.name == "friendlyBullet(Clone)")
        {
            //destory the object and add score
            Destroy(gameObject);
            GamePlayManager.updateScore(10);
        }

        //if there is a collision between enemy
        if (collision.gameObject.name == "Turret")
        {
            //destory the enemy object
            Destroy(gameObject);
        }

    }

}
