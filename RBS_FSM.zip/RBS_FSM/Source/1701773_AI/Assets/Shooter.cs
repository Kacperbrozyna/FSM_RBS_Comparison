﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Shooter: MonoBehaviour
{
    //creating states 
    enum State { lookOut = 0, Shoot = 1, Reload = 2, Repair = 3 };
    State turretState;

    //declaring variables
    public Transform firePoint;
    public GameObject bulletPreFab;

    public Sprite spriteLookout;
    public Sprite spriteShooting;
    public Sprite spriteReloading;
    public Sprite spriteRepairing;

    private gameplayManager GamePlayManager;
    private SpriteRenderer bannerSpriteRenderer;
    public GameObject Banner;

    public float turretFireRate = 1f;
    public float bulletForce = 20f;
    private float nextFire = 0.0f;
    private int currentAmmo;
    public int maxAmmo = 30;

    public float reloadTime = 1f;
    public float repairTime = 1f;
    private bool isReloading = false;
    private bool isRepairing = false;

   
    private int currentHealth;
    public int maxHealth = 100;

    // Start is called before the first frame update
    void Start()
    {
        //sets the variables at the start
        currentAmmo = maxAmmo;
        GamePlayManager = GameObject.FindObjectOfType<gameplayManager>();
        GamePlayManager.updateAmmo(currentAmmo);
        currentHealth = maxHealth;
        GamePlayManager.updateHealth(currentHealth);
        GamePlayManager.updateScore(0);

        bannerSpriteRenderer = Banner.GetComponent<SpriteRenderer>();
        turretState = State.lookOut;
        newState(turretState);
    }

    // Update is called once per frame
    void Update()
    {
        //if turret has zero or less health then end the application
        if (currentHealth <= 0)
        {
            Application.Quit();
        }

        //if the turret is reloading then return
        else if (isReloading)
        {
            return;
        }
        //if the turret is reparing then return
        else if (isRepairing)
        {
            return;
        }

        //if the conditions are met then switch to that state and do the state specific action
        else if (Time.time > nextFire && currentAmmo > 0 && GamePlayManager.shoot == true)
        {
                turretState = State.Shoot;
                newState(turretState);
                stateActions(turretState);
        }

        //if repair transition is true switch state to repair
     else if ( GamePlayManager.repair == true)
        {
                turretState = State.Repair;
                newState(turretState);
              stateActions(turretState);
        }

        //if reload transition is true switch state to reload
      else if (GamePlayManager.reload == true)
        {
                turretState = State.Reload;
                newState(turretState);
                stateActions(turretState);
        }

        //if wait transition is true switch to the lookout state
      else if (GamePlayManager.wait== true)
        {
                turretState = State.lookOut;
                newState(turretState);
        }
    }


    void stateActions(State currentState)
    {
        //depending on the state call the appropriate action
        switch (currentState)
        {
            case State.Shoot:
                turretShoot();
                break;
            case State.Reload:
                StartCoroutine(turretReload());
                break;
            case State.Repair:
                StartCoroutine(turretRepair());
                break;
            default:
                break;
        }
    }

    void newState(State currentState)
    {
        //depending on the state change the appropriate banner
        switch (currentState)
        {
            case State.lookOut:
                bannerSpriteRenderer.sprite = spriteLookout;
                break;
            case State.Shoot:
                bannerSpriteRenderer.sprite = spriteShooting; 
                break;
            case State.Reload:
                bannerSpriteRenderer.sprite = spriteReloading;
                break;
            case State.Repair:
                bannerSpriteRenderer.sprite = spriteRepairing;
                break;
            default:
                break;
        }
    }

    void turretShoot()
    {
        //create a bullet object and applies a force to it
        GameObject bullet = Instantiate(bulletPreFab, firePoint.position, firePoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);

        //updates conditions and variables
        nextFire = Time.time + 1 / turretFireRate;
        currentAmmo--;
        GamePlayManager.updateAmmo(currentAmmo);
        GamePlayManager.currentAmmo = currentAmmo;
    }

    IEnumerator turretReload()
    {
        //update variables after waiting for the specific reloading time
        isReloading = true;
        yield return new WaitForSeconds(reloadTime);
        currentAmmo = maxAmmo;
        GamePlayManager.updateAmmo(currentAmmo);
        isReloading = false;
    }

    IEnumerator turretRepair()
    {
        //update variables after waiting for the specific repair time
        isRepairing = true;
        yield return new WaitForSeconds(repairTime);
        currentHealth = maxHealth;
        GamePlayManager.updateHealth(currentHealth);
        isRepairing = false;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        //if there is a collision between these objects and a turret 
        if (collision.gameObject.name == "enemyBullet(Clone)" || collision.gameObject.name == "enemyShip(Clone)")
        {
            //update health 
            currentHealth -= 10;
            GamePlayManager.updateHealth(currentHealth);
        }

    }
}


