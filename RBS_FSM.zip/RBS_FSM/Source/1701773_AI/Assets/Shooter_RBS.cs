﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooter_RBS : MonoBehaviour
{
    //declaring variables
    public Transform firePoint;
    public GameObject bulletPreFab;

    public Sprite spriteShooting;
    public Sprite spriteReloading;
    public Sprite spriteRepairing;
    public Sprite spriteWaiting;

    private gameplayManager GamePlayManager;
    private SpriteRenderer bannerSpriteRenderer;
    public GameObject Banner;

    public float turretFireRate = 1f;
    public float bulletForce = 20f;
    private float nextFire = 0.0f;
    private int currentAmmo;
    public int maxAmmo = 30;

    public float reloadTime = 1f;
    public float repairTime = 1f;
    private bool isReloading = false;
    private bool isRepairing = false;

    private int currentHealth;
    public int maxHealth = 100;

    // Start is called before the first frame update
    void Start()
    {
        //sets variables at the start 
        currentAmmo = maxAmmo;
        GamePlayManager = GameObject.FindObjectOfType<gameplayManager>();
        GamePlayManager.updateAmmo(currentAmmo);
        currentHealth = maxHealth;
        GamePlayManager.updateHealth(currentHealth);
        GamePlayManager.updateScore(0);

        bannerSpriteRenderer = Banner.GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        //if turret has zero or less health then end the application
        if (currentHealth <= 0)
        {
            Application.Quit();
        }

        //if the turret is reloading then return
        else if (isReloading)
        {
            return;
        }
        //if the turret is reparing then return
        else if (isRepairing)
        {
            return;
        }

        //if conditions are met then fire the turret and change the sprite
        else if (Time.time > nextFire && currentAmmo > 0 && GamePlayManager.shoot == true)
        { 
            turretShoot();
            bannerSpriteRenderer.sprite = spriteShooting;
        }

        //if repair is true then repair the turret and change the sprite
        else if (GamePlayManager.repair == true)
        { 
            StartCoroutine(turretRepair());
            bannerSpriteRenderer.sprite = spriteRepairing;
        }

        //if reload is true then reload the turret and change the sprite
        else if (GamePlayManager.reload == true)
        {
            StartCoroutine(turretReload());
            bannerSpriteRenderer.sprite = spriteReloading;
        }

        //if all the actions are false change the banner to waiting
        else if (GamePlayManager.reload == false &&
                GamePlayManager.repair == false &&
                GamePlayManager.shoot == false)
            bannerSpriteRenderer.sprite = spriteWaiting;

    }

    void turretShoot()
    {
        //create a bullet object and applies a force to it
        GameObject bullet = Instantiate(bulletPreFab, firePoint.position, firePoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);

        //updates conditions and variables
        nextFire = Time.time + 1 / turretFireRate;
        currentAmmo--;
        GamePlayManager.updateAmmo(currentAmmo);
        GamePlayManager.currentAmmo = currentAmmo;
    }

    IEnumerator turretReload()
    {
        //update variables after waiting for the specific reloading time
        isReloading = true;
        yield return new WaitForSeconds(reloadTime);
        currentAmmo = maxAmmo;
        GamePlayManager.updateAmmo(currentAmmo);
        isReloading = false;
    }

    IEnumerator turretRepair()
    {
        //update variables after waiting for the specific repair time
        isRepairing = true;
        yield return new WaitForSeconds(repairTime);
        currentHealth = maxHealth;
        GamePlayManager.updateHealth(currentHealth);
        isRepairing = false;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        //if there is a collision between these objects and a turret 
        if (collision.gameObject.name == "enemyBullet(Clone)" || collision.gameObject.name == "enemyShip(Clone)")
        {
            //update health 
            currentHealth -= 10;
            GamePlayManager.updateHealth(currentHealth);
        }

    }
}
