﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    //declaring variables
    public GameObject enemy;
    public float spawnWait;
    public float spawnMostWait;
    public float spawnLeastWait;
    public float startWait;

    // Start is called before the first frame update
    void Start()
    {
        //starting to spawn enemies
        StartCoroutine(spawn());
    }

    // Update is called once per frame
    void Update()
    {
        //gets the random amount of time before an enemy spawns
        spawnWait = Random.Range(spawnLeastWait, spawnMostWait);
    }

    IEnumerator spawn()
    {
        //waiting a certain amount before spawning enemies
        yield return new WaitForSeconds(startWait);

        //always spawning until the application ends
        while (true)
        {
            //spawns an enemy object ontop of the spawner
            Instantiate(enemy, transform.position, transform.rotation);

            //waiting before spawning another enemy
            yield return new WaitForSeconds(spawnWait);

        }
    }


}
