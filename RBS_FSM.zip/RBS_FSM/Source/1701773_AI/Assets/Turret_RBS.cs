﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret_RBS : MonoBehaviour
{

    //declaring variables
    private gameplayManager GamePlayManager;

    public Rigidbody2D rb;
    Enemy closestShip;

    private bool inRange;
    private int repairPrio;
    private int reloadPrio;
    private double ammoValue;
    private float healthValue;

    // Start is called before the first frame update
    void Start()
    {
        //setting variables at the start
        GamePlayManager = GameObject.FindObjectOfType<gameplayManager>();
        inRange = false;
    }

    // Update is called once per frame
    void Update()
    {
        //resetting variables/actions
        GamePlayManager.shoot = false;
        GamePlayManager.reload = false;
        GamePlayManager.repair = false;
        GamePlayManager.wait = false;
        reloadPrio = 3;
        repairPrio = 3;

        //calls function to find the closest ship 
        findClosestShip();
        //calls function to rotate the turret
        fixedRotation();

        // if a ship is in range of the turret runs this condition
        if (inRange)
        {
            //if the turret has no ammo set the priority of reloading
            if (GamePlayManager.currentAmmo == 0)
            {
                reloadPrio = 1;
            }

            //if the health of the turret is low then set the priority of repairing
            if (GamePlayManager.currentHealth <= 50)
            {
                repairPrio = 1;
            }

            // if neither reloading and repairing have a high priority then the turret will shoot
            if (repairPrio != 1 && reloadPrio != 1)
            {
                GamePlayManager.shoot = true;
            }

            // if both reloading and repairing have a high priority then perform conflict resolution
            else
                actionResolution();

        }

        // if a ship is not in range of the turret
        else
        {
            //if the health of the turret is not the max then set to medium priority
            if (GamePlayManager.currentHealth != 100)
            {
                repairPrio = 2;

            }
            //if the health of the turret is even less set the priority to high
            else if (GamePlayManager.currentHealth <= 60)
            {
                repairPrio = 1;
            }

            // if the ammo of the turret is slightly below the max then set priority to medium
            if (GamePlayManager.currentAmmo <= 25)
            {
                reloadPrio = 2;
            }

            // if the ammo of the turret is even lower then set the priority to high
            else if (GamePlayManager.currentAmmo <= 15)
            {
                reloadPrio = 1;
            }

            //if there is no priority just wait for the ship to come in range
            if (repairPrio == 3 && reloadPrio == 3)
            {
                GamePlayManager.wait = true;
            }

            //if the priority of repair is lower than reload then set the repair bool to true
           else if (repairPrio < reloadPrio)
            {
                GamePlayManager.repair = true;
            }

            //if the priority of reload is lower then set the reload bool to true
            else if (repairPrio > reloadPrio)
            {
                GamePlayManager.reload = true;
            }

            //if priorities are the same call conflict resolution
            else
                actionResolution();

        }
    }

    void findClosestShip()
    {
        //creates a array of enemies if there are any on the field
        float distanceToClosestEnemy = 50.0f;
        Enemy[] allEnemies = GameObject.FindObjectsOfType<Enemy>();

        //if there are no enemies it returns
        if (allEnemies == null)
            return;

        //loops through all the enemies
        foreach (Enemy currentEnemy in allEnemies)
        {
            float distanceToEnemy = (currentEnemy.transform.position - this.transform.position).sqrMagnitude;

            //if the enemy is less than range of the turret assign the range to that ship
            if (distanceToEnemy < distanceToClosestEnemy)
            {
                distanceToClosestEnemy = distanceToEnemy;
                closestShip = currentEnemy;
            }
        }

        //if the enemy is within the turret range set bool to true
        if (distanceToClosestEnemy < 50f)
            inRange = true;
        //if not set bool to false
        else
            inRange = false;

    }

    void fixedRotation()
    {
        //if there is no ship that is in range then return
        if (closestShip == null)
            return;

        //getting the direction of the turret and the ship then rotate turret towards the ship
        Vector2 lookDir = (Vector2)closestShip.transform.position - rb.position;
        float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg;
        rb.rotation = angle - 90;
    }

    void actionResolution()
    {
        //calls function to update value of ammo and health
        updateValue();
        //if the value of ammo is less than health then set the bool of the respective action
        if (ammoValue < healthValue)
            GamePlayManager.reload = true;
        //else set the bool of the other action
        else
            GamePlayManager.repair = true;
    }

    void updateValue()
    {
        //value of ammo is equal to the current ammo
        ammoValue = GamePlayManager.currentAmmo;
        //value of ammo is equal to the current health divived by 5
        healthValue = GamePlayManager.currentHealth / 5;
    }
}
