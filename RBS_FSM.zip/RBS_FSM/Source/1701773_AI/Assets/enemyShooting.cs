﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyShooting : MonoBehaviour
{
    //declaring variables
    public Transform firePoint;
    public GameObject bulletPreFab;
    public GameObject target;
    public float bulletForce = 20f;
    public float fireRate = 0.5f;
    private float nextFire = 0.0f;

    float distance;

    // Update is called once per frame
    void Update()
    {
        //gets the distance between the turret and the enemy
        distance = Vector3.Distance(target.transform.position, transform.position);

        //if the distance between the enemy and the turret is less than the amount shoot a bullet
        if (distance <= 1.75 && Time.time > nextFire)
        {
            nextFire = Time.time +  1 / fireRate;
            Shoot();
        }
    }

    void Shoot()
    {
        //creates a bullet object and applies a force to it
        GameObject bullet = Instantiate(bulletPreFab, firePoint.position, firePoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce(firePoint.up * bulletForce, ForceMode2D.Impulse);
    }

    

}




