﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class gameplayManager : MonoBehaviour
{
    //declaring variables
    public Text healthText;
    public Text scoreText;
    public Text ammoText;
    public Text timeText;

    public int currentScore;
    public bool shoot;
    public bool repair;
    public bool reload;
    public bool wait;
    public bool reloading;
    public bool repairing;
    public int currentAmmo =30;
    public int currentHealth;
    public float enemyMoveSpeed = 1;

    private int scoreSpeed = 1000;

    private void Update()
    {
        //updates the time text to the current time
        timeText.text = "Time: " + Time.time.ToString();

        //if current score is greater then increase the movement speed of the enemy
        if (scoreSpeed <= currentScore)
        {
            scoreSpeed += 1000;
            enemyMoveSpeed = enemyMoveSpeed * 1.5f;
        }
    }

    public void updateHealth(int health)
    {
        //update the health text
        healthText.text = "Health: " + health.ToString();
        currentHealth = health;
    }

    public void updateScore(int score)
    {
        //at the start of the game update the score to zero
        if (score == 0)
        {
            scoreText.text = "Score: " + score.ToString();
            currentScore = 0;
        }
        //else add score to the current score and updates the score text
        else 
        {
            currentScore += score;
            scoreText.text = "Score: " + currentScore.ToString();
        }
    }

    public void updateAmmo(int ammo)
    {
        //updates the current ammo text
        ammoText.text = "Ammo: " + ammo.ToString() + "/30";
        currentAmmo = ammo;
    }
}
