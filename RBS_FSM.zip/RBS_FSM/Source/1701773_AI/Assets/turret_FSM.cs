﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class turret_FSM : MonoBehaviour
{
    //declaring variables
    private gameplayManager GamePlayManager;
    public Rigidbody2D rb;
    Enemy closestShip;
    private bool inRange;

    // Start is called before the first frame update
    void Start()
    {
        //setting variables at the start of the game
        GamePlayManager = GameObject.FindObjectOfType<gameplayManager>();
        inRange = false;
        GamePlayManager.wait = true;
    }

    // Update is called once per frame
    void Update()
    {

        //calls function to find the closest ship 
        findClosestShip();
        //calls function to rotate the turret
        fixedRotation();

        //if the bool is true call the actions in lookoutState
        if (GamePlayManager.wait == true)
        {
            lookoutState();
        }

        //if the bool is true call the actions in shootState
        else if (GamePlayManager.shoot == true)
        {
            shootState();
        }

        //if the bool is true call the actions in reloadState
        else if (GamePlayManager.reload == true)
        {
            reloadState();
        }

        //if the bool is true call the actions in repairState
        else if (GamePlayManager.repair == true)
        {
            repairState();
        }
    }

    void findClosestShip()
    {
        //creates a array of enemies if there are any on the field
        float distanceToClosestEnemy = 50.0f;
        Enemy[] allEnemies = GameObject.FindObjectsOfType<Enemy>();

        //if there are no enemies it returns
        if (allEnemies == null)
            return;

        //loops through all the enemies
        foreach (Enemy currentEnemy in allEnemies)
        {
            float distanceToEnemy = (currentEnemy.transform.position - this.transform.position).sqrMagnitude;

            //if the enemy is less than range of the turret assign the range to that ship
            if (distanceToEnemy < distanceToClosestEnemy)
            {
                distanceToClosestEnemy = distanceToEnemy;
                closestShip = currentEnemy;
            }
        }

        //if the enemy is within the turret range set bool to true
        if (distanceToClosestEnemy < 50f)
            inRange = true;
        //if not set bool to false
        else
            inRange = false;

    }

    void fixedRotation()
    {
        //if there is no ship that is in range then return
        if (closestShip == null)
            return;

        //getting the direction of the turret and the ship then rotate turret towards the ship
        Vector2 lookDir = (Vector2)closestShip.transform.position - rb.position;
        float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg;
        rb.rotation = angle - 90;
    }

    void lookoutState()
    {
        //in there is an enemy in range
        if (inRange == true)
        {
            //reset the states and set the state to shoot
            resetStates();
            GamePlayManager.shoot = true; 
        }

      else  if (inRange == false)
        {
            //if the current health is not the max
            if (GamePlayManager.currentHealth != 100)
            {
                //reset the states and set the state to repair
                resetStates();
                GamePlayManager.repair = true;
            }

            //if the current ammo is not the max
         else   if (GamePlayManager.currentAmmo != 30)
            {
                //reset the states and set the state to reload
                resetStates();
                GamePlayManager.reload = true;
            }
        }
    }

    void shootState()
    {
        //if there are no enemies in range
        if (inRange == false)
        {
            //reset the states and set the state to lookOut
            resetStates();
            GamePlayManager.wait = true;
        }

        //if the current ammo is empty
        else if (GamePlayManager.currentAmmo == 0)
        {
            //reset the states and set the state to reload
            resetStates();
            GamePlayManager.reload = true;
        }

        //if health is really low
        else if (GamePlayManager.currentHealth == 10)
        {
            //reset the states and set the state to repair
            resetStates();
            GamePlayManager.repair = true;
        }

    }

    void repairState()
    {
        //if current health is full
        if (GamePlayManager.currentHealth == 100)
        {
            //reset the states and set the state to lookOut
            resetStates();
            GamePlayManager.wait = true;
        }
    
    
    }
     void reloadState()
    {
        //if the current health is max
        if (GamePlayManager.currentAmmo == 30)
        {
            //reset the states and set the state to lookOut
            resetStates();
            GamePlayManager.wait = true;
        }
    
    }

    void resetStates()
    {
        //reset all the states using the bools
        GamePlayManager.wait = false;
        GamePlayManager.shoot = false;
        GamePlayManager.reload = false;
        GamePlayManager.repair = false;
    }
 
}
